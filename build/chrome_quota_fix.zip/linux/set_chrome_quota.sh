#!/bin/sh

if command -v sqlite3 > /dev/null
then true
else
	echo 'You need to have SQLite 3 installed.'
	sleep 3
	exit 1
fi

FOUND_CHROME=0
CHROMIUM_DB_PATH=${HOME}/.config/chromium/Default/databases/Databases.db
CHROME_DB_PATH=${HOME}/.config/google-chrome/Default/databases/Databases.db

if [ -f ${CHROMIUM_DB_PATH} ]
then 
	echo 'Found Chromium profile, updating...'
	FOUND_CHROME=1
	sqlite3 "${CHROMIUM_DB_PATH}" "INSERT OR REPLACE INTO Quota VALUES('http_danbooru.donmai.us_0', 20971520)"
	sqlite3 "${CHROMIUM_DB_PATH}" "INSERT OR REPLACE INTO Quota VALUES('http_safebooru.donmai.us_0', 20971520)"
else
	echo 'No Chromium profile found.'
fi

if [ -f ${CHROME_DB_PATH} ]
then 
	echo 'Found Chrome profile, updating...'
	FOUND_CHROME=1
	sqlite3 "${CHROME_DB_PATH}" "INSERT OR REPLACE INTO Quota VALUES('http_danbooru.donmai.us_0', 20971520)"
	sqlite3 "${CHROME_DB_PATH}" "INSERT OR REPLACE INTO Quota VALUES('http_safebooru.donmai.us_0', 20971520)"
else
	echo 'No Chrome profile found.'
fi


if [ ${FOUND_CHROME} -eq 0 ]
then
	echo 'Could not locate a Chrome or Chromium profile.'
	echo 'You may have to visit Danbooru with the extension installed to create the database index.'
	sleep 3
	exit 1
else
	echo 'Success! DanbooruUp disk quota is 20MB.'
	echo 'You can now restart Chrome and enable updates.'
	sleep 3
fi
