// Find the Chrome database index and increase Danbooru's quota.

var WshShell = WScript.CreateObject('WScript.Shell');
var FileSystem = WScript.CreateObject('Scripting.FileSystemObject');

var local_app_data = WshShell.RegRead('HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Shell Folders\\Local AppData');

var db_path = local_app_data + '\\Google\\Chrome\\User Data\\Default\\databases\\Databases.db';

if (!FileSystem.FileExists(db_path)) {
	WshShell.Popup('Could not find Chrome database index at ' + db_path +
		'\nYou may have to visit Danbooru with the extension installed to create the database index.');
} else if (!FileSystem.FileExists('sqlite3.exe')) {
	WshShell.Popup('Could not find sqlite3.exe');
} else {
	WshShell.Exec('sqlite3.exe "' + db_path + '" "INSERT OR REPLACE INTO Quota ' +
		"VALUES('http_danbooru.donmai.us_0', " + (20 << 20) + ')"');
	WshShell.Exec('sqlite3.exe "' + db_path + '" "INSERT OR REPLACE INTO Quota ' +
		"VALUES('http_safebooru.donmai.us_0', " + (20 << 20) + ')"');
	WshShell.Popup('Success! DanbooruUp disk quota is 20MB.\nYou can now restart Chrome and enable updates.');
}
